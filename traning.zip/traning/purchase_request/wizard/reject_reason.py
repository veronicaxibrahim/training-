# -*- coding: utf-8 -*-

from odoo import _, api, exceptions, models,fields


class RejectReasonWizard(models.TransientModel):
    _name = 'reject.reason.wizard'

    rejection_reason = fields.Text()
    reject_id = fields.Many2one('purchase.request')

    def action_cancel(self):
        print('cancel')

    def action_confirm(self):
        rejection = self.env['purchase.request'].create({
            'rejection_reason_purchase': self.rejection_reason,
            'requested_by': self.write_uid.id,
        })
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'purchase.request',
            'view_mode': 'form',
            'res_id': rejection.id,

        }
        self.reject_id.state = 'reject'
