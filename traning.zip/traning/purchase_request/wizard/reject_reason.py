# -*- coding: utf-8 -*-

from odoo import _, api, exceptions, models,fields


class RejectReasonWizard(models.TransientModel):
    _name = 'reject.reason.wizard'

    rejection_reason = fields.Text()
    reject_id = fields.Many2one('purchase.request')


    def action_cancel(self):
        print('cancel')

    def action_confirm(self):
        print('confirm')