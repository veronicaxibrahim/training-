# -*- coding: utf-8 -*-
from importlib_resources._common import _

from odoo import models, fields, api


class PurchaseRequest(models.Model):
    _name = 'purchase.request'

    request_name = fields.Char()

    requested_by = fields.Many2one('res.users', required=True,default=lambda self: self.env.user)
    start_date = fields.Date(default=fields.Date.today)
    rejection_reason_purchase = fields.Text()
    end_date = fields.Date()
    state = fields.Selection(
        [('draft', 'Draft'), ('to be approved', 'To Be Approved'), ('approve', 'Approve'), ('reject', 'Reject'),
         ('cancel', 'Cancel')], string='Status', default='draft')
    request_line_ids = fields.One2many('purchase.request.lines', 'request_line_id')

    # @api.model
    # def create(self, vals):
    #     if vals.get('name', 'New') == 'New':
    #         vals['sequence'] = self.env['ir.sequence'].next_by_code('purchase.request') or 'New'
    #     return super(PurchaseRequest, self).create(vals)

    def action_to_be_approved(self):
        for rec in self:
            rec.state = 'to be approved'


    def action_cancel(self):
        for rec in self:
            rec.state = 'cancel'

    def action_reject_reason(self):
        wizard = self.env['reject.reason.wizard'].create({

            'rejection_reason': self.rejection_reason_purchase
        })
        return {
         'name': _('Test Wizard'),
         'type': 'ir.actions.act_window',
         'res_model': 'reject.reason.wizard',
         'view_mode': 'form',
          'res_id': wizard.id,
          'target': 'new',
             }


    def action_approve(self):
        for rec in self:
            rec.state = 'approve'
            mail_template = rec.env.ref('purchase.request.email_approve_template')
            mail_template.send_mail(rec.id, force_send=True)


    def  action_reset_to_draft(self):
            self.state = 'draft'


class PurchaseRequestLines(models.Model):
    _name = 'purchase.request.lines'

    request_line_id = fields.Many2one('purchase.request', string='Purchase order')

    product_id = fields.Many2one('product.product', required=True)
    description = fields.Text()
    quantity = fields.Float(default=1)
    cost_price = fields.Float(related='product_id.standard_price',readonly=True)
    total = fields.Float(readonly=True, compute="_compute_total_price")
    total_price = fields.Float()
    state = fields.Selection(
        [('draft', 'Draft'), ('to be approved', 'To Be Approved'), ('approve', 'Approve'), ('reject', 'Reject'),
         ('cancel', 'Cancel')], string='Status', readonly=True, default='draft')

    @api.onchange('product_id')
    def _onchange_description(self):
        for record in self:
            record.description = record.product_id.name

    @api.depends('quantity', 'cost_price')
    def _compute_total_price(self):
        for rec in self:
            if rec.quantity and rec.total > 0:
                rec.total = rec.quantity * rec.cost_price

